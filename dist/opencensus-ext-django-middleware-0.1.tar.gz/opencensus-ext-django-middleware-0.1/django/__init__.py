#!usr/bin/env python 
# -*- coding:utf-8 _*-
"""
@author:ivan
@file: __init__.py.py 
@version:
@time: 2019/05/22 
@email:chongwuwy@163.com
"""
__title__ = 'opencensus-ext-django-middleware'
__version__ = '0.1'
__author__ = 'ivan'
__license__ = 'BSD 2-Clause'
__copyright__ = 'Copyright 2019-2025 ivan'

# Version synonym
VERSION = __version__

